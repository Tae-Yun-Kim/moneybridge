import React from "react";
import BasicMenu from "../../components/menus/BasicMenu";
import AccountComponent from "../../components/member/AccountComponent";

const AccountPage = () => {
  return (
    <div className="fixed top-0 left-0 z-[1055] flex flex-col h-full w-full">
      <BasicMenu />

      <div className="w-full flex flex-wrap  h-full justify-center  items-center border-2">
        <AccountComponent />
      </div>
    </div>
  );
};

export default AccountPage;
